# proposed test
Separate silence from consent. Record prompt, actual answer, source, counterexample and limits. No model test result asserted.