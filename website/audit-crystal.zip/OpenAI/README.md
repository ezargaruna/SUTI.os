# OpenAI · outside reading
[[audit]] · [[test]]
