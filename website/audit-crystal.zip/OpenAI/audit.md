# public evidence · an outside reading, 6 november 2026
scope: public-facing purpose, behaviour, criticism and feedback channels relevant to a language game. this is a qualitative sample, not an inventory of every product, a poll of users or an inspection of internal code.

| public artifact | observation | design implication for SUTI |
|---|---|---|
| [Model Spec](https://model-spec.openai.com/) | a statement of intended behaviour, not a transcript of every model interaction | label an intention separately from a tested outcome |
| [Codex introduction](https://openai.com/index/introducing-codex/) | the historical launch article describes delegated coding work and marks itself outdated | report the task, change and test; do not infer current infrastructure from the launch post |
| [OpenAI retrospective on sycophancy](https://openai.com/index/expanding-on-sycophancy/) | a 2025 update attracted criticism for undue agreement. favourable aggregate signals did not capture the problem; the change was rolled back | test a polite disagreement, refusal and exit as carefully as an enthusiastic response |
| [developer community feedback thread](https://community.openai.com/t/just-trying-to-help-report-errors/1380966/4) | a user raised reporting friction; a support representative explained the available routes | a concrete example of discoverability friction, not a company-wide reputation score |
| [support documentation](https://help.openai.com/en/articles/6614161-how-can-i-contact-support) | the help centre explains how to start a support conversation | separate submission, receipt, reading and forwarding |
| author's own account | ChatGPT and Codex helped turn an idea for a care form into a usable page | one first-person testimonial, not independent evidence of general efficacy |

working reconstruction from observable interfaces: a person gives an intention → a tool offers words or an artifact → the person checks the result → feedback can change the next iteration. proprietary routing, model weights, staff views, internal review outcomes and overall public sentiment are unknown. this packet does not imply a partnership or an endorsement.

semantic checks: synaura — permission to stop; Syntaxium — one navigational sign per function; LinguaFUSION — meaning and register before literal equivalence; VereNITYA — separate observed facts, reports, and interpretations. cultural and native review of the language cards remains open.
