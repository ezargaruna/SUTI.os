# SUTI · system guide · thirteen draft editions

[open the offline portal](system-guide-13l/index.html) · [guide and language index](system-guide-13l/README.md) · [rights and publication notice](NOTICE.md)

This archive preserves all 56 reviewed source-package files under system-guide-13l/. It contains 13 guide routes, 17 role specifications and locale configurations. YZH is experimental authorial notation with Russian semantic gloss, separate from the common living layer's Russian-gloss/HOLD route.

The owner authorized public display of this draft on 13 November 2026. Independent language review, host enforcement, runtime activation and release of a new reuse license are not implied. Run system-guide-13l/tools/verify_package.py against that preserved source directory for its checksum and link checks.
