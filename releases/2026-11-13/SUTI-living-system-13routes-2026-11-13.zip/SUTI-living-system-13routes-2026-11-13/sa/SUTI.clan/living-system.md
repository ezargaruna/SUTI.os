# SUTI.clan · सहकार्यम्

locale :: sa
source_locale :: ru
state :: direct-source-draft-unreviewed
release :: HOLD
source_sha256 :: a546e8b55ba1f9ab230d5001e68ad7caed47a02a7afc3542535413b9a138b312


भूमिकाः, योगदानं, सहभागितासीमाश्च सम्मत्या निश्चितुम्

सामान्यकार्यं निर्दिश → स्पष्टां सहभागितां याचस्व → अधिकारान् भूमिकां च सम्मत्या निश्चितं कुरु → निर्णयं रक्ष

सहभागिनां सम्मतिः उत्तरदायित्वमानचित्रं च

मानचित्रे व्यक्तेः संस्थायाः वा नाम सहकारसम्बन्धं सम्मतिं वा न बोधयति

[SUTI · सामान्य जीवन्तव्यवस्था](../living-system.md) · [जीवनस्य जीवनप्रेमिणां च समर्थननिधिः · परिचर्यादूतानां संस्था](../care-90-days.md)

[ru · source](../../_techne/machine/collective-living-system-v1/source.ru.json)
