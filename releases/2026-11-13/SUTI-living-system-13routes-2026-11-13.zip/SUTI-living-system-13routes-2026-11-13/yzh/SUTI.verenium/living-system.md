# SUTI.verenium · навигация заботы

locale :: yzh
source_locale :: ru
state :: not-started-author-gloss-required
release :: HOLD
source_sha256 :: a546e8b55ba1f9ab230d5001e68ad7caed47a02a7afc3542535413b9a138b312


помогать человеку выбрать посильную помощь и собственный шаг

спроси, что важно → предложи понятные варианты → уточни границы → оставь выбор, паузу и выход

выбранный маршрут помощи и согласованное действие

ангел заботы — добровольный образ; сервис не является экстренной или клинической службой

[SUTI · Язэхъ · смысловая развёртка](../living-system.md) · [фонд поддержки жизни и любящих жизнь · агентство ангелов заботы](../care-90-days.md)

[ru · source](../../_techne/machine/collective-living-system-v1/source.ru.json)
