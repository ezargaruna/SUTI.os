# SUTI.world · публичный вход

locale :: yzh
source_locale :: ru
state :: not-started-author-gloss-required
release :: HOLD
source_sha256 :: a546e8b55ba1f9ab230d5001e68ad7caed47a02a7afc3542535413b9a138b312


помочь человеку найти нужное направление и следующий шаг

назови вопрос → выбери язык → открой подходящий модуль → попробуй один доступный шаг

понятный маршрут и выбранное действие

масштаб сети и польза подтверждаются наблюдениями, не обещанием

[SUTI · Язэхъ · смысловая развёртка](../living-system.md) · [фонд поддержки жизни и любящих жизнь · агентство ангелов заботы](../care-90-days.md)

[ru · source](../../_techne/machine/collective-living-system-v1/source.ru.json)
