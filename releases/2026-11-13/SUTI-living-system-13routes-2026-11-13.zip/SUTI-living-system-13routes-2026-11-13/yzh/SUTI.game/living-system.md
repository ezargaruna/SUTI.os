# SUTI.game · добровольная практика

locale :: yzh
source_locale :: ru
state :: not-started-author-gloss-required
release :: HOLD
source_sha256 :: a546e8b55ba1f9ab230d5001e68ad7caed47a02a7afc3542535413b9a138b312


исследовать навыки через игру NITYA и Samurai Dharma

выбери обычный или символический язык → возьми малый квест → попробуй → запиши наблюдение или пропусти → выбери продолжение

опыт практики и собственный следующий шаг

игра добровольна; пауза, пропуск и выход доступны; возрастные дорожки требуют отдельной проверки

[SUTI · Язэхъ · смысловая развёртка](../living-system.md) · [фонд поддержки жизни и любящих жизнь · агентство ангелов заботы](../care-90-days.md)

[ru · source](../../_techne/machine/collective-living-system-v1/source.ru.json)
