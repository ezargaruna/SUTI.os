# SUTI.lab · исследование

locale :: yzh
source_locale :: ru
state :: not-started-author-gloss-required
release :: HOLD
source_sha256 :: a546e8b55ba1f9ab230d5001e68ad7caed47a02a7afc3542535413b9a138b312


проверять идеи небольшими обратимыми пробами

назови гипотезу → выбери наблюдаемый признак → проведи ограниченную пробу → запиши результат и сомнения

исследовательская запись с основаниями

гипотеза и символ не становятся фактом без проверки

[SUTI · Язэхъ · смысловая развёртка](../living-system.md) · [фонд поддержки жизни и любящих жизнь · агентство ангелов заботы](../care-90-days.md)

[ru · source](../../_techne/machine/collective-living-system-v1/source.ru.json)
